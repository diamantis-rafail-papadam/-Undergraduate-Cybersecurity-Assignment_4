#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
//#include <math.h>

#include <openssl/sha.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/conf.h>
#include <openssl/cmac.h>

#define BLOCK_SIZE 16
#define MAX_MSG_SIZE 50000

size_t cmac_length = 16;

/* function prototypes */
void print_hex(unsigned char *, size_t);
void print_string(unsigned char *, size_t); 
void usage(void);
void check_args(char *, char *, unsigned char *, int, int);
bool keygen(unsigned char *, unsigned char *, unsigned char *, int);
int encrypt(unsigned char *, int, unsigned char *, unsigned char *, unsigned char *, int);
int decrypt(unsigned char *, int, unsigned char *, unsigned char *, unsigned char *, int);
int gen_cmac(unsigned char *, size_t, unsigned char *, unsigned char* , unsigned char *, int);
bool verify_cmac(unsigned char *, unsigned char *, size_t);

/* TODO Declare your function prototypes here... */
//bool choose_cipher(EVP_CIPHER* (*cipher)(void), int bit_mode);
int taskE(unsigned char *, size_t, unsigned char *, unsigned char*, int);
unsigned char* get_cmac(unsigned char*, size_t, size_t);

/*
 * Prints the hex value of the input
 * 16 values per line
 */
void print_hex(unsigned char *data, size_t len) {
	size_t i;

	if (!data)
		printf("NULL data\n");
	else {
		for (i = 0; i < len; i++) {
			if (!(i % BLOCK_SIZE) && (i != 0))
				printf("\n");
			printf("%02X ", data[i]);
		}
		printf("\n");
	}
}


/*
 * Prints the input as string
 */
void print_string(unsigned char *data, size_t len) {
	size_t i;

	if (!data)
		printf("NULL data\n");
	else {
		for (i = 0; i < len; i++)
			printf("%c", data[i]);
		printf("\n");
	}
}


/*
 * Prints the usage message
 * Describe the usage of the new arguments you introduce
 */
void usage(void) {
	printf(
	    "\n"
	    "Usage:\n"
	    "    assign_2 -i in_file -o out_file -p passwd -b bits" 
	        " [-d | -e | -g | -v]\n"
	    "    assign_2 -h\n"
	);
	printf(
	    "\n"
	    "Options:\n"
	    " -i    path    Path to input file\n"
	    " -o    path    Path to output file\n"
	    " -p    psswd   Password for key generation\n"
	    " -b    bits    Bit mode (128 or 256 only)\n"
	    " -d            Decrypt input and store results to output\n"
	    " -e            Encrypt input and store results to output\n"
	    " -g            Encrypt+sign input and store results to output\n"
	    " -v            Decrypt+verify input and store results to output\n"
	    " -h            Prints help message\n"
	);
	exit(EXIT_FAILURE);
}


/*
 * Checks the validity of the arguments
 * Check the new arguments you introduce
 */
void check_args(char *input_file, char *output_file, unsigned char *password,  int bit_mode, int op_mode) {
	if (!input_file) {
		printf("Error: No input file!\n");
		usage();
	}

	if (!output_file) {
		printf("Error: No output file!\n");
		usage();
	}

	if (!password) {
		printf("Error: No user key!\n");
		usage();
	}

	if ((bit_mode != 128) && (bit_mode != 256)) {
		printf("Error: Bit Mode <%d> is invalid!\n", bit_mode);
		usage();
	}

	if (op_mode == -1) {
		printf("Error: No mode\n");
		usage();
	}
}
/*
bool choose_cipher(EVP_CIPHER * (*cipher)(void), int bit_mode) {
	if(bit_mode == 128)
		cipher = &EVP_aes_128_ecb;
	else if(bit_mode == 256)
		cipher = &EVP_aes_256_ecb;
	else {
		printf("ERROR: Invalid bit_mode...\n");
		return false;
	}
	return true;
}
*/

/*
 * Generates a key using a password
 */
bool keygen(unsigned char *password, unsigned char *key, unsigned char *iv, int bit_mode) {
	unsigned int size = strlen((char*) password);
	if(bit_mode == 128)
		EVP_BytesToKey(EVP_aes_128_ecb(), EVP_sha1(), NULL, password, size, 1, key, iv);
	else if(bit_mode == 256)
		EVP_BytesToKey(EVP_aes_256_ecb(), EVP_sha1(), NULL, password, size, 1, key, iv);
	else {
		printf("ERROR: Invalid bit_mode...\n");
		return false;
	}
	//EVP_MD_CTX* evp_ctx = EVP_MD_CTX_new();
    //EVP_DigestInit_ex(evp_ctx, EVP_sha1(), NULL);
	//EVP_DigestUpdate(evp_ctx, password, size);	
	//EVP_DigestFinal_ex(evp_ctx, key, &size);
	//EVP_MD_CTX_free(evp_ctx);

	//print_hex(key, bit_mode/8);
	
	return true; //success
}


/*
 * Encrypts the data and returns the ciphertext size
 */
int encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, unsigned char *ciphertext, int bit_mode) {
	EVP_CIPHER_CTX* cipher_ctx = EVP_CIPHER_CTX_new(); 
	const EVP_CIPHER* (*cipher)(void);
	if(bit_mode == 128)
		cipher = &EVP_aes_128_ecb;
	else if(bit_mode == 256)
		cipher = &EVP_aes_256_ecb;
	else {
		printf("ERROR: Invalid bit_mode...\n");
		return false;
	}
	int size, cipher_size;
	EVP_EncryptInit_ex(cipher_ctx, (*cipher)(), NULL, key, iv);
	EVP_EncryptUpdate(cipher_ctx, ciphertext, &cipher_size, plaintext, plaintext_len);
	EVP_EncryptFinal_ex(cipher_ctx, ciphertext + cipher_size, &size);
	EVP_CIPHER_CTX_free(cipher_ctx);
	return cipher_size + size;
}

/*
 * Decrypts the data and returns the plaintext size
 */
int decrypt(unsigned char *plaintext, int ciphertext_len, unsigned char *key, unsigned char *iv, unsigned char *ciphertext, int bit_mode) {
	int size, plaintext_size;
	EVP_CIPHER_CTX* decipher_ctx = EVP_CIPHER_CTX_new();
	const EVP_CIPHER * (*cipher)(void);
	if(bit_mode == 128)
		cipher = &EVP_aes_128_ecb;
	else if(bit_mode == 256)
		cipher = &EVP_aes_256_ecb;
	else {
		printf("ERROR: Invalid bit_mode...\n");
		return -1;
	}
	EVP_DecryptInit_ex(decipher_ctx, (*cipher)(), NULL, key, iv);
	EVP_DecryptUpdate(decipher_ctx, plaintext, &plaintext_size, ciphertext, ciphertext_len);
	EVP_DecryptFinal_ex(decipher_ctx, plaintext + plaintext_size, &size);
	EVP_CIPHER_CTX_free(decipher_ctx);
	return plaintext_size + size;
}


/*
 * Generates a CMAC
 */
int gen_cmac(unsigned char *data, size_t data_len, unsigned char *key, unsigned char* cipher_text, unsigned char *cmac, int bit_mode) {
	int encrypted_size;
	size_t cmac_size;
	if((encrypted_size = encrypt(data, data_len, key, NULL, cipher_text, bit_mode)) == -1)
		return false;
	const EVP_CIPHER * (*cipher)(void);
	if(bit_mode == 128)
		cipher = &EVP_aes_128_ecb;
	else if(bit_mode == 256)
		cipher = &EVP_aes_256_ecb;
	else {
		printf("ERROR: Invalid bit_mode...\n");
		return -1;
	}
	CMAC_CTX *cmac_ctx = CMAC_CTX_new();
	CMAC_Init(cmac_ctx, key, bit_mode/8, (*cipher)(), NULL);
	CMAC_Update(cmac_ctx, data, data_len);
	CMAC_Final(cmac_ctx, cmac, &cmac_size);
	CMAC_CTX_free(cmac_ctx);
	//print_hex(cmac, cmac_size);
	//printf("cmac size: %d\n", cmac_size);
	cmac_length = cmac_size;
	return encrypted_size;
}


/*
 * Verifies a CMAC
 */
int taskE(unsigned char *new_msg, size_t msg_size, unsigned char *key, unsigned char* cipher_msg, int bit_mode) {
	int decrypted_size;
	unsigned char* cmac1 =  get_cmac(cipher_msg, msg_size, cmac_length);
	unsigned char* cmac2 = (unsigned char*)calloc(sizeof(char), bit_mode/8);
	if((decrypted_size = decrypt(new_msg, (int)msg_size - cmac_length, key, NULL, cipher_msg, bit_mode)) == -1)
		return false;
	const EVP_CIPHER * (*cipher)(void);
	if(bit_mode == 128)
		cipher = &EVP_aes_128_ecb;
	else if(bit_mode == 256)
		cipher = &EVP_aes_256_ecb;
	else {
		printf("ERROR: Invalid bit_mode...\n");
		return -1;
	}
	//print_hex(cipher_msg, msg_size);
	//printf("%s %d\n", new_msg, cmac_length);
	CMAC_CTX *cmac_ctx = CMAC_CTX_new();
	CMAC_Init(cmac_ctx, key, bit_mode/8, (*cipher)(), NULL);
	CMAC_Update(cmac_ctx, new_msg, decrypted_size);
	CMAC_Final(cmac_ctx, cmac2, &cmac_length);
	//print_hex(cmac1, cmac_length);
	//print_hex(cmac2, cmac_length);
	CMAC_CTX_free(cmac_ctx);
	if(!verify_cmac(cmac1, cmac2, cmac_length)) {
		printf("ERROR: The cmacs do not match...\n");
		return -1;
	}
	free(cmac2);
	return decrypted_size;
}

unsigned char* get_cmac(unsigned char* msg, size_t msg_size, size_t cmac_size) {
	unsigned char* cmac = (unsigned char*)calloc(sizeof(char), 256); //It will never have greater size than than
	for(int i = msg_size - cmac_size; i < msg_size; i++)
		cmac[i - msg_size + cmac_size] = msg[i];
	return cmac;
}

bool verify_cmac(unsigned char *cmac1, unsigned char *cmac2, size_t size) {
	for(int i = 0; i < size; i++) {
		if(cmac1[i] != cmac2[i])
			return false;
	}
	return true;
}



/* TODO Develop your functions here... */



/*
 * Encrypts the input file and stores the ciphertext to the output file
 *
 * Decrypts the input file and stores the plaintext to the output file
 *
 * Encrypts and signs the input file and stores the ciphertext concatenated with 
 * the CMAC to the output file
 *
 * Decrypts and verifies the input file and stores the plaintext to the output
 * file
 */
int main(int argc, char **argv) {
	int opt;			/* used for command line arguments */
	int bit_mode;			/* defines the key-size 128 or 256 */
	int op_mode;			/* operation mode */
	char input_file[100] = "../files/";		/* path to the input file */
	char output_file[100] = "../files/";		/* path to the output file */
	unsigned char *password;	/* the user defined password */

	/* Init arguments */
	password = NULL;
	bit_mode = -1;
	op_mode = -1;


	/*
	 * Get arguments
	 */
	while ((opt = getopt(argc, argv, "b:i:m:o:p:degvh:")) != -1) {
		switch (opt) {
		case 'b':
			bit_mode = atoi(optarg);
			break;
		case 'i':
			strcat(input_file, optarg);
			break;
		case 'o':
			strcat(output_file, optarg);
			break;
		case 'p':
			password = (unsigned char *)strdup(optarg);
			break;
		case 'e':
			/* if op_mode == 0 the tool encrypts */
			op_mode = 0;
			break;
		case 'd':
			/* if op_mode == 1 the tool decrypts */
			op_mode = 1;
			break;
		case 'g':
			/* if op_mode == 2 the tool signs */
			op_mode = 2;
			break;
		case 'v':
			/* if op_mode == 3 the tool verifies */
			op_mode = 3;
			break;
		case 'h':
		default:
			usage();
		}
	}


	/* check arguments */
	check_args(input_file, output_file, password, bit_mode, op_mode);

	/* TODO Develop the logic of your tool here... */
	long int input_size;
	unsigned char* msg = (unsigned char *)malloc(MAX_MSG_SIZE*sizeof(char));
	FILE *input_fp, *output_fp;
	if((input_fp = fopen(input_file, "r")) == NULL) {
		printf("ERROR: Input file not found...\n");
		return -1;
	}
	fseek (input_fp, 0, SEEK_END);
	input_size = ftell(input_fp);
	fseek (input_fp, 0, SEEK_SET);
	if(fread(msg, 1, input_size, input_fp) == 0) {
		printf("ERROR: Failed to read input file or it is empty...\n");
		return -1;
	}
	if((output_fp = fopen(output_file, "w")) == NULL) {
		printf("ERROR: Output file could not be created...\n");
		return -1;
	}
	
 
	/* Initialize the library */
	unsigned char* key = (unsigned char*)calloc(sizeof(char), bit_mode/8);
	unsigned char* new_text = (unsigned char*)malloc(MAX_MSG_SIZE*sizeof(char));
	unsigned char* cmac = (unsigned char*)calloc(sizeof(char), bit_mode/8);
	int new_text_len;

	/* Keygen from password */
	if(!keygen(password, key, NULL, bit_mode))
		return -1;
	//print_hex(key, bit_mode/8);

	/* Operate on the data according to the mode */
	if(op_mode == 0) { /* encrypt */
		if((new_text_len = encrypt(msg, input_size, key, NULL, new_text, bit_mode)) == -1)
			return -1;
		fwrite(new_text, sizeof(unsigned char), new_text_len, output_fp);
	}
	else if(op_mode == 1) { /* decrypt */
		if((new_text_len = decrypt(new_text, input_size, key, NULL, msg, bit_mode)) == -1)
			return -1;
		fwrite(new_text, sizeof(unsigned char), new_text_len, output_fp);
	}
	else if(op_mode == 2) { /* sign */
		if((new_text_len = gen_cmac(msg, input_size, key, new_text, cmac, bit_mode)) == -1)
			return -1;
		fwrite(new_text, sizeof(unsigned char), new_text_len, output_fp);
		fwrite(cmac, sizeof(unsigned char), cmac_length, output_fp);
	}
	else if(op_mode == 3) { /* verify */
		if((new_text_len = taskE(new_text, input_size, key, msg, bit_mode)) == -1)
			return -1;
		fwrite(new_text, sizeof(unsigned char), new_text_len, output_fp);
	}
		
	else
		printf("ERROR: Invalid op_mode\n");

	/* Clean up */
	//free(input_file);
	//free(output_file);
	free(password);
	free(new_text);
	free(key);
	free(cmac);
	fclose(input_fp);
	fclose(output_fp);

	/* END */
	return 0;
}
